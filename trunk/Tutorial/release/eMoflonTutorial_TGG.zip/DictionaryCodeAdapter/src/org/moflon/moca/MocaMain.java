package org.moflon.moca;

import java.io.File;
import org.apache.log4j.BasicConfigurator;
import org.moflon.moca.dictionary.parser.DictionaryParserAdapter;
import org.moflon.moca.dictionary.unparser.DictionaryUnparserAdapter;
import org.moflon.util.eMoflonEMFUtil;

import DictionaryCodeAdapter.DictionaryCodeAdapterFactory;
import DictionaryCodeAdapter.Transformer;
import DictionaryLanguage.Library;
import Moca.CodeAdapter;
import Moca.MocaFactory;
import MocaTree.Folder;
import MocaTree.MocaTreePackage;

public class MocaMain {

	private static CodeAdapter codeAdapter;

	public static void main(String[] args) {
		BasicConfigurator.configure();

		// Register parsers and unparsers
		codeAdapter = MocaFactory.eINSTANCE.createCodeAdapter();
		codeAdapter.getParser().add(new DictionaryParserAdapter());
		codeAdapter.getUnparser().add(new DictionaryUnparserAdapter());

		// Perform text-to-tree
		Folder tree = codeAdapter.parse(new File("instances/in/"));

		// Save tree to file
		eMoflonEMFUtil.saveModel(MocaTreePackage.eINSTANCE, tree,
				"instances/tree.xmi");

		// Perform tree-to-model
		Transformer transformer = DictionaryCodeAdapterFactory.eINSTANCE
				.createTransformer();
		transformer.transformFolders(tree);

		// Save model to file
		for (Library library : transformer.getTransformedLibraries())
			eMoflonEMFUtil.saveModel(MocaTreePackage.eINSTANCE, library,
					"instances/" + library.getName() + ".xmi");

		// Perform model-to-tree
		transformer.setFileExtension(".dictionary");
		Folder out = transformer.transformLibraries();

		// Save tree to file
		eMoflonEMFUtil.saveModel(MocaTreePackage.eINSTANCE, out,
				"instances/out.xmi");

		// Perform tree-to-text (using initial tree)
		codeAdapter.unparse("instances", out);
	}
}